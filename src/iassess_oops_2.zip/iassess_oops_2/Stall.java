package iassess_oops_2;

public interface Stall {
	void display();
}
